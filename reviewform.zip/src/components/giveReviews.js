import React from "react";
import "./giveReviews.css";

const giveReviews = () => {
  return <div>giveReviews</div>;
};

export default giveReviews;
